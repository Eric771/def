function kalive() {
  const http = require('http');
  const server = http.createServer((req, res) => {
    if (req.url === '/') {
      res.statusCode = 200;
      res.setHeader('Content-Type', 'text/plain');
      res.end('Drop a ⭐ if this worked for you!');
    } else {
      res.statusCode = 404;
      res.setHeader('Content-Type', 'text/plain');
      res.end('Not Found');
    }
  });

  const port = process.env.PORT || 80 || 3500;

  server.listen(port, () => {
    console.log(`Server is running on port ${port}`);
  });
}
module.exports = {
  kalive
}

/*
To keep your repl alive
1 run the repl
2 take the link
3 use uptimerobot or cronitor to make a new monitor
4 make it ping your repl every 5 or less minutes
*/