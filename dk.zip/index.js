const Discord = require('discord.js-selfbot-v13');
const { DiscordStreamClient } = require('discord-stream-client');
const ffmpegPath = require('@ffmpeg-installer/ffmpeg').path;
const ffmpeg = require('fluent-ffmpeg');
ffmpeg.setFfmpegPath(ffmpegPath);
const client = new Discord.Client();
new DiscordStreamClient(client);
const time = [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000];

client.on('messageCreate', message => {
  const content = message.content.toLocaleLowerCase()
  if (content === 'السلام عليكم') {
      setTimeout(() => {
      message.channel.send("وعليكم السلام");
    }, time[Math.floor(Math.random() * time.length)]);
  }
});
client.on('messageCreate', message => {
  const content = message.content.toLocaleLowerCase()
  if (content === 'Welcome , Enjoy in Pact :Emaj4:') {
      setTimeout(() => {
      message.channel.send("Welcome , Enjoy in Pact :Emaj4:");
    }, time[Math.floor(Math.random() * time.length)]);
  }
});
client.on('messageCreate', message => {
  const content = message.content.toLocaleLowerCase()
  if (content === 'صباح الخير') {
      setTimeout(() => {
      message.channel.send("صباح النور");
    }, time[Math.floor(Math.random() * time.length)]);
  }
});
client.on('messageCreate', message => {
  const content = message.content.toLocaleLowerCase()
  if (content === 'هاي') {
      setTimeout(() => {
      message.channel.send("هااايااات");
    }, time[Math.floor(Math.random() * time.length)]);
  }
});
client.on('messageCreate', message => {
  const content = message.content.toLocaleLowerCase()
  if (content === 'كت؟') {
      setTimeout(() => {
      message.channel.send("قووو");
    }, time[Math.floor(Math.random() * time.length)]);
  }
});
client.on('ready', async client => {
  console.log('Ready!', client.user.tag);
  const channel = client.channels.cache.get('1192438940653850665');
  const connection = await client.streamClient.joinVoiceChannel(channel, {
    selfDeaf: true,
    selfMute: true,
    selfVideo: false,
  });
  const stream = await connection.createStream();
  const player = client.streamClient.createPlayer(
    'https://rr1---sn-q4fzen7s.googlevideo.com/videoplayback?expire=1705529676&ei=7PynZaD7Hbi2y_sP3_mK4Ao&ip=102.129.153.175&id=o-AG-ElucjxXdpi5WBA1nb5EFk56_i_ZL5JNyjY9WrHdMb&itag=22&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&mh=UZ&mm=31%2C29&mn=sn-q4fzen7s%2Csn-q4fl6nd6&ms=au%2Crdu&mv=m&mvi=1&pl=24&initcwndbps=861250&spc=UWF9fzdkYbYqjzCKyhPsPXMUMMXcJxkCNfrl&vprv=1&svpuc=1&mime=video%2Fmp4&cnr=14&ratebypass=yes&dur=86399.454&lmt=1688258331781624&mt=1705507499&fvip=1&fexp=24007246&c=ANDROID&txp=5532434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Ccnr%2Cratebypass%2Cdur%2Clmt&sig=AJfQdSswRgIhAPuO48O4VGuneFBn6NZwQYJbgrvxroTHpRzbEvHPRIKtAiEAjzQ-9QKyOLieRgY72ziYm4B6R3L9c8M0WS1mvlahFpw%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AAO5W4owRQIhAK59-cYhIVA86-bu8op-1AuJN3vhbNWI4aM4vYMaFLooAiAaZaLQZ2tdYRfELwSifYdmNMpABUI9yoFNTBNj5LinBw%3D%3D&title=Playing%20Minecraft%20Hardcore%20for%2024%20HOURS%20Straight!%20%5BFULL%20MOVIE%5D',
    stream.udp,
  );
  player.on('error', err => console.error(err));
  player.play({
    kbpsVideo: 1080, // FHD 60fps
    fps: 60,
    hwaccel: true,
    kbpsAudio: 128,
    volume: 1,
  });
});

client.login('MTE4MDYwNjY4MDU0Mzc5MzIzMw.Gc-iRA.5b6k29yoo2TvEQE6O_iQaNta7QpQc4UYfrtfC0');